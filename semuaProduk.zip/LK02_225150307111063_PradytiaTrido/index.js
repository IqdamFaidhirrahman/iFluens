const express = require('express');
const mysql = require('mysql2/promise');
const dotenv = require('dotenv');

dotenv.config();
const app = express();
app.use(express.json());

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_DATABASE,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

app.get('/todos', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT id, title, description, priority, completed FROM todos');
    const todos = rows.map(row => ({
      id: row.id,
      title: row.title,
      description: row.description,
      priority: row.priority,
      completed: Boolean(row.completed),
    }));
    res.json(todos);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /todos
app.post('/todos', async (req, res) => {
  try {
    const { title, description, priority } = req.body;
    const [result] = await pool.query(
      'INSERT INTO todos (title, description, priority) VALUES (?, ?, ?)',
      [title, description, priority]
    );
    res.status(201).json({ id: result.insertId });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// PUT /todos/:id
app.put('/todos/:id', async (req, res) => {
  try {
    const { title, description, priority, completed } = req.body;
    const { id } = req.params;
    await pool.query(
      'UPDATE todos SET title = ?, description = ?, priority = ?, completed = ? WHERE id = ?',
      [title, description, priority, completed, id]
    );
    res.json({ message: 'Todo updated' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/todos/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM todos WHERE id = ?', [id]);
    res.json({ message: 'Todo deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
