const db = require("../config/db");

exports.berikanFeedback = (req, res) => {
  const { user_id, kelas_id, rating, komentar } = req.body;

  if (!user_id || !kelas_id || !rating) {
    return res.status(400).json({ message: "user_id, kelas_id, dan rating wajib diisi" });
  }

  const query = `
    INSERT INTO feedback_kelas (user_id, kelas_id, rating, komentar)
    VALUES (?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
      rating = VALUES(rating),
      komentar = VALUES(komentar),
      tanggal_feedback = CURRENT_TIMESTAMP
  `;

  db.query(query, [user_id, kelas_id, rating, komentar], (err, result) => {
    if (err) {
      console.error("Gagal menyimpan feedback:", err);
      return res.status(500).json({ message: "Terjadi kesalahan saat menyimpan feedback" });
    }

    res.status(200).json({ message: "Feedback berhasil disimpan!" });
  });
};