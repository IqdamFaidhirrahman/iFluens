const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');
const nodemailer = require('nodemailer');
const { v4: uuidv4 } = require('uuid');
const dayjs = require('dayjs');

// REGISTER
const registerUser = async (req, res) => {
  const { username, nama, email, password, konfirmasiPassword, no_hp } = req.body;

  if (password !== konfirmasiPassword) {
    return res.status(400).json({ message: "Konfirmasi password tidak cocok" });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const sql = "INSERT INTO user (username, nama, email, password, no_hp) VALUES (?, ?, ?, ?, ?)";
    const values = [username, nama, email, hashedPassword, no_hp];

    db.query(sql, values, (err, result) => {
      if (err) {
        console.error("Error saat register:", err);
        return res.status(500).json({ message: "Gagal register", error: err });
      }
      return res.status(201).json({ message: "Register berhasil" });
    });
  } catch (error) {
    return res.status(500).json({ message: "Terjadi kesalahan saat register" });
  }
};

// LOGIN
const loginUser = async (req, res) => {
  const { email, password } = req.body;

  db.query("SELECT * FROM user WHERE email = ?", [email], async (err, results) => {
    if (err) return res.status(500).json({ message: "Kesalahan server" });

    if (results.length === 0) {
      return res.status(404).json({ message: "Email tidak ditemukan" });
    }

    const user = results[0];
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.status(401).json({ message: "Password salah" });
    }

    // ✅ Buat token dengan menyertakan ID dan email
    const token = jwt.sign(
      { id: user.ID_User, email: user.email },
      process.env.JWT_SECRET || "RAHASIA123",
      { expiresIn: "1h" }
    );

    return res.status(200).json({
      message: "Login berhasil",
      user: {
        id: user.ID_User,
        email: user.email,
        nama: user.nama
      },
      token
    });
  });
};

// FORGOT PASSWORD
const forgotPassword = (req, res) => {
  const { email } = req.body;
  const token = uuidv4();
  const expires = dayjs().add(1, 'hour').format('YYYY-MM-DD HH:mm:ss');

  const checkUser = "SELECT * FROM user WHERE email = ?";
  db.query(checkUser, [email], (err, results) => {
    if (err) return res.status(500).json({ error: "Database error" });
    if (results.length === 0) return res.status(404).json({ message: "Email tidak ditemukan" });

    const updateUser = "UPDATE user SET reset_token = ?, reset_expires = ? WHERE email = ?";
    db.query(updateUser, [token, expires, email], (err) => {
      if (err) return res.status(500).json({ error: "Token update error" });

      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: process.env.EMAIL_USER,
          pass: process.env.EMAIL_PASS,
        },
      });

      const resetLink = `http://localhost:5000/auth/reset-password/${token}`;
      const mailOptions = {
        from: process.env.EMAIL_USER,
        to: email,
        subject: "Password Reset",
        html: `<p>Click <a href="${resetLink}">here</a> to reset your password. Link valid 1 jam.</p>`,
      };

      transporter.sendMail(mailOptions, (err) => {
        if (err) return res.status(500).json({ error: "Gagal mengirim email" });
        res.json({ message: "Link reset telah dikirim ke email Anda" });
      });
    });
  });
};

// RESET PASSWORD
const resetPassword = (req, res) => {
  const { token } = req.params;
  const { newPassword } = req.body;
  const now = dayjs().format('YYYY-MM-DD HH:mm:ss');

  const checkToken = "SELECT * FROM user WHERE reset_token = ? AND reset_expires > ?";
  db.query(checkToken, [token, now], async (err, results) => {
    if (err) return res.status(500).json({ error: "Database error" });
    if (results.length === 0) return res.status(400).json({ message: "Token tidak valid atau telah kedaluwarsa" });

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    const updateQuery = "UPDATE user SET password = ?, reset_token = NULL, reset_expires = NULL WHERE reset_token = ?";

    db.query(updateQuery, [hashedPassword, token], (err) => {
      if (err) return res.status(500).json({ error: "Gagal mengubah password" });
      res.json({ message: "Password berhasil diubah" });
    });
  });
};

module.exports = {
  registerUser,
  loginUser,
  forgotPassword,
  resetPassword
};
