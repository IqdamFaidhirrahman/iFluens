const db = require("../config/db");

exports.tambahKelas = (req, res) => {
  const { nama_kelas, deskripsi, is_premium } = req.body;

  const query = "INSERT INTO kelas (nama_kelas, deskripsi, is_premium) VALUES (?, ?, ?)";
  db.query(query, [nama_kelas, deskripsi, is_premium ? 1 : 0], (err, result) => {
    if (err) {
      console.error("Gagal menambahkan kelas:", err);
      return res.status(500).json({ message: "Terjadi kesalahan server." });
    }

    res.status(201).json({
      message: "Kelas berhasil ditambahkan!",
      data: { id: result.insertId, nama_kelas, deskripsi, is_premium: is_premium ? 1 : 0 },
    });
  });
};

exports.getSemuaKelas = (req, res) => {
  const { user_id } = req.query;

  const query = "SELECT * FROM kelas";
  db.query(query, async (err, results) => {
    if (err) {
      console.error("Gagal mengambil data kelas:", err);
      return res.status(500).json({ message: "Terjadi kesalahan server." });
    }

    // Jika tidak ada user_id, kembalikan biasa
    if (!user_id) {
      return res.status(200).json({
        message: "Data kelas berhasil diambil!",
        data: results,
      });
    }

    // Hitung progress per kelas
    const kelasDenganProgress = await Promise.all(
      results.map((kelas) => {
        return new Promise((resolve) => {
          const kelasId = kelas.id;
          const totalQuery = `
            SELECT 
              (SELECT COUNT(*) FROM lesson WHERE kelas_id = ?) AS total_lesson,
              (SELECT COUNT(*) FROM quiz WHERE kelas_id = ?) AS total_quiz
          `;

          db.query(totalQuery, [kelasId, kelasId], (err, totalResult) => {
            if (err || totalResult.length === 0) {
              kelas.progress = 0;
              kelas.status = "ongoing";
              return resolve(kelas);
            }

            const { total_lesson, total_quiz } = totalResult[0];
            const totalItem = total_lesson + total_quiz;

            if (totalItem === 0) {
              kelas.progress = 0;
              kelas.status = "ongoing";
              return resolve(kelas);
            }

            const progressQuery = `
              SELECT
                (SELECT COUNT(*) FROM lesson_progress_user lp
                 JOIN lesson l ON lp.lesson_id = l.id
                 WHERE lp.user_id = ? AND l.kelas_id = ? AND lp.status = 'sudah') AS lesson_done,
                (SELECT COUNT(*) FROM quiz_progress_user qp
                 JOIN quiz q ON qp.quiz_id = q.id
                 WHERE qp.user_id = ? AND q.kelas_id = ? AND qp.status = 'sudah') AS quiz_done
            `;

            db.query(progressQuery, [user_id, kelasId, user_id, kelasId], (err, result) => {
              if (err || result.length === 0) {
                kelas.progress = 0;
                kelas.status = "ongoing";
                return resolve(kelas);
              }

              const { lesson_done, quiz_done } = result[0];
              const progress = Math.round(((lesson_done + quiz_done) / totalItem) * 100);

              kelas.progress = progress;
              kelas.status = progress === 100 ? "completed" : "ongoing";

              return resolve(kelas);
            });
          });
        });
      })
    );

    return res.status(200).json({
      message: "Data kelas berhasil diambil!",
      data: kelasDenganProgress,
    });
  });
};

exports.getKelasById = (req, res) => {
  const { id } = req.params;
  const { user_id } = req.query;

  const queryKelas = "SELECT * FROM kelas WHERE id = ?";
  db.query(queryKelas, [id], (err, results) => {
    if (err) {
      console.error("Gagal mengambil data kelas:", err);
      return res.status(500).json({ message: "Terjadi kesalahan server." });
    }

    if (results.length === 0) {
      return res.status(404).json({ message: "Kelas tidak ditemukan." });
    }

    const kelas = results[0];

    const selesaikanResponse = () => {
      res.status(200).json({
        message: "Detail kelas berhasil diambil!",
        data: kelas
      });
    };

    const hitungJumlahPesertaDanRating = () => {
      const pesertaQuery = `SELECT COUNT(*) AS jumlah_peserta FROM user_course WHERE kelas_id = ?`;
      db.query(pesertaQuery, [id], (err, pesertaResult) => {
        if (err) {
          console.error("Gagal mengambil jumlah peserta:", err);
          return res.status(500).json({ message: "Gagal mengambil jumlah peserta" });
        }

        kelas.jumlah_peserta = pesertaResult[0].jumlah_peserta;

        const ratingQuery = `SELECT AVG(rating) AS rata_rating FROM feedback_kelas WHERE kelas_id = ?`;
        db.query(ratingQuery, [id], (err, ratingResult) => {
          if (err) {
            console.error("Gagal mengambil rating:", err);
            return res.status(500).json({ message: "Gagal mengambil rating" });
          }

          const rating = ratingResult[0].rata_rating;
          kelas.rata_rating = rating !== null ? parseFloat(parseFloat(rating).toFixed(1)) : null;

          selesaikanResponse();
        });
      });
    };

    // Jika tidak ada user_id, tidak perlu hitung progress
    if (!user_id) {
      return hitungJumlahPesertaDanRating();
    }

    const totalQuery = `
      SELECT 
        (SELECT COUNT(*) FROM lesson WHERE kelas_id = ?) AS total_lesson,
        (SELECT COUNT(*) FROM quiz WHERE kelas_id = ?) AS total_quiz
    `;

    db.query(totalQuery, [id, id], (err, totalResult) => {
      if (err) {
        console.error("Gagal mengambil jumlah materi:", err);
        return res.status(500).json({ message: "Gagal mengambil progress" });
      }

      const { total_lesson, total_quiz } = totalResult[0];
      const totalItem = total_lesson + total_quiz;

      if (totalItem === 0) {
        kelas.progress = 0;
        return hitungJumlahPesertaDanRating();
      }

      const userProgressQuery = `
        SELECT
          (SELECT COUNT(*) FROM lesson_progress_user lp
           JOIN lesson l ON lp.lesson_id = l.id
           WHERE lp.user_id = ? AND l.kelas_id = ? AND lp.status = 'sudah') AS lesson_done,
          (SELECT COUNT(*) FROM quiz_progress_user qp
           JOIN quiz q ON qp.quiz_id = q.id
           WHERE qp.user_id = ? AND q.kelas_id = ? AND qp.status = 'sudah') AS quiz_done
      `;

      db.query(userProgressQuery, [user_id, id, user_id, id], (err, userResult) => {
        if (err) {
          console.error("Gagal mengambil progress user:", err);
          return res.status(500).json({ message: "Gagal mengambil progress user" });
        }

        const { lesson_done, quiz_done } = userResult[0];
        const progress = Math.round(((lesson_done + quiz_done) / totalItem) * 100);

        kelas.progress = progress;
        hitungJumlahPesertaDanRating();
      });
    });
  });
};

exports.getMateriByKelas = (req, res) => {
  const { id } = req.params;
  const { user_id } = req.query;

  const lessonQuery = `
    SELECT 
      l.id, l.judul, l.deskripsi, l.video_url, l.thumbnail_url, l.created_at,
      'lesson' AS type,
      COALESCE(lp.status, 'belum') AS status
    FROM lesson l
    LEFT JOIN lesson_progress_user lp 
      ON lp.lesson_id = l.id AND lp.user_id = ?
    WHERE l.kelas_id = ?
  `;

  const quizQuery = `
    SELECT 
      q.id, q.judul, q.deskripsi, 
      NULL AS video_url, NULL AS thumbnail_url, q.created_at,
      'quiz' AS type,
      COALESCE(qp.status, 'belum') AS status
    FROM quiz q
    LEFT JOIN quiz_progress_user qp 
      ON qp.quiz_id = q.id AND qp.user_id = ?
    WHERE q.kelas_id = ?
  `;

  const combinedQuery = `
    (${lessonQuery})
    UNION ALL
    (${quizQuery})
    ORDER BY created_at ASC
  `;

  db.query(combinedQuery, [user_id, id, user_id, id], (err, results) => {
    if (err) {
      console.error("Gagal mengambil materi:", err);
      return res.status(500).json({ message: "Terjadi kesalahan server." });
    }

    res.status(200).json({
      message: "Daftar materi berhasil diambil!",
      data: results
    });
  });
};

exports.updateKelas = (req, res) => {
  const { id } = req.params;
  const { nama_kelas, deskripsi } = req.body;

  const query = "UPDATE kelas SET nama_kelas = ?, deskripsi = ? WHERE id = ?";
  db.query(query, [nama_kelas, deskripsi, id], (err, result) => {
    if (err) {
      console.error("Gagal mengupdate kelas:", err);
      return res.status(500).json({ message: "Terjadi kesalahan server." });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Kelas tidak ditemukan." });
    }

    res.status(200).json({
      message: "Kelas berhasil diperbarui!",
      data: {
        id: parseInt(id),
        nama_kelas,
        deskripsi,
      },
    });
  });
};

exports.hapusKelas = (req, res) => {
  const { id } = req.params;

  const query = "DELETE FROM kelas WHERE id = ?";
  db.query(query, [id], (err, result) => {
    if (err) {
      console.error("Gagal menghapus kelas:", err);
      return res.status(500).json({ message: "Terjadi kesalahan server." });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Kelas tidak ditemukan." });
    }

    res.status(200).json({ message: "Kelas berhasil dihapus!" });
  });
};