const db = require('../config/db');

exports.submitQuiz = (req, res) => {
  const { user_id, quiz_id, jawaban } = req.body;

  if (!user_id || !quiz_id || !Array.isArray(jawaban)) {
    return res.status(400).json({ message: 'Data tidak lengkap.' });
  }

  const getSoalQuery = 'SELECT id, jawaban_benar FROM quiz_question WHERE quiz_id = ?';
  db.query(getSoalQuery, [quiz_id], (err, rows) => {
    if (err) return res.status(500).json({ message: 'Gagal mengambil soal.' });

    const jawabanMap = {};
    rows.forEach(row => jawabanMap[row.id] = row.jawaban_benar);

    let benar = 0;
    jawaban.forEach(j => {
      if (jawabanMap[j.question_id] && jawabanMap[j.question_id] === j.jawaban_user) {
        benar++;
      }
    });

    const totalSoal = rows.length;
    const skor = Math.round((benar / totalSoal) * 100);

    const updateProgress = `
      INSERT INTO quiz_progress_user (user_id, quiz_id, status, tanggal_diselesaikan)
      VALUES (?, ?, 'sudah', NOW())
      ON DUPLICATE KEY UPDATE status = 'sudah', tanggal_diselesaikan = NOW()
    `;

    db.query(updateProgress, [user_id, quiz_id], (err2) => {
      if (err2) return res.status(500).json({ message: 'Gagal menyimpan progress.' });

      res.status(200).json({
        message: 'Quiz berhasil disubmit.',
        hasil: {
          skor: `${skor}%`,
          jumlah_benar: benar,
          total_soal: totalSoal
        }
      });
    });
  });
};
