const db = require('../config/db');

exports.markLessonAsWatched = (req, res) => {
  const { user_id, lesson_id } = req.body;

  const checkQuery = `SELECT * FROM lesson_progress_user WHERE user_id = ? AND lesson_id = ?`;
  db.query(checkQuery, [user_id, lesson_id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });

    if (result.length > 0) {
      const updateQuery = `UPDATE lesson_progress_user SET status = 'sudah' WHERE user_id = ? AND lesson_id = ?`;
      db.query(updateQuery, [user_id, lesson_id], (err2) => {
        if (err2) return res.status(500).json({ error: err2.message });
        return res.json({ message: 'Progress updated ✅' });
      });
    } else {
      const insertQuery = `INSERT INTO lesson_progress_user (user_id, lesson_id, status) VALUES (?, ?, 'sudah')`;
      db.query(insertQuery, [user_id, lesson_id], (err3) => {
        if (err3) return res.status(500).json({ error: err3.message });
        return res.json({ message: 'Progress saved ✅' });
      });
    }
  });
};

exports.tambahLesson = (req, res) => {
  const { kelas_id, judul, deskripsi, video_url, thumbnail_url } = req.body;

  if (!kelas_id || !judul) {
    return res.status(400).json({ message: "kelas_id dan judul wajib diisi." });
  }

  const query = `
    INSERT INTO lesson (kelas_id, judul, deskripsi, video_url, thumbnail_url)
    VALUES (?, ?, ?, ?, ?)
  `;

  db.query(query, [kelas_id, judul, deskripsi || null, video_url || null, thumbnail_url || null], (err, result) => {
    if (err) {
      console.error("Gagal menambahkan lesson:", err);
      return res.status(500).json({ message: "Terjadi kesalahan server." });
    }

    res.status(201).json({
      message: "Lesson berhasil ditambahkan!",
      data: {
        id: result.insertId,
        kelas_id,
        judul,
        deskripsi,
        video_url,
        thumbnail_url
      }
    });
  });
};

