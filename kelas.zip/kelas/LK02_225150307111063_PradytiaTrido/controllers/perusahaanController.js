// controllers/perusahaanController.js

const db = require('../config/db');

// Menambahkan perusahaan baru
const addPerusahaan = (req, res) => {
  const { nama_perusahaan, alamat } = req.body;

  if (!nama_perusahaan || !alamat) {
    return res.status(400).json({ error: 'nama_perusahaan dan alamat wajib diisi' });
  }

  const checkSql = `SELECT * FROM perusahaan WHERE nama_perusahaan = ?`;
  db.query(checkSql, [nama_perusahaan], (err, rows) => {
    if (err) {
      console.error('Error saat mengecek perusahaan:', err);
      return res.status(500).json({ error: 'Gagal memeriksa data perusahaan' });
    }

    if (rows.length > 0) {
      return res.status(400).json({ error: 'Perusahaan sudah terdaftar' });
    }

    const insertSql = `INSERT INTO perusahaan (nama_perusahaan, alamat) VALUES (?, ?)`;
    db.query(insertSql, [nama_perusahaan, alamat], (err2, result) => {
      if (err2) {
        console.error('Gagal menambahkan perusahaan:', err2);
        return res.status(500).json({ error: 'Gagal menambahkan perusahaan' });
      }

      res.status(201).json({
        message: 'Perusahaan berhasil ditambahkan',
        id_perusahaan: result.insertId,
        nama_perusahaan,
        alamat
      });
    });
  });
};


module.exports = { addPerusahaan };
