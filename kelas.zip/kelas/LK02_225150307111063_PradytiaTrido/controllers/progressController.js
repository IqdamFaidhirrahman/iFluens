const db = require("../config/db");

exports.getUserProgress = (req, res) => {
  const { user_id, kelas_id } = req.params;

  // Hitung total lesson & quiz di kelas
  const totalQuery = `
    SELECT 
      (SELECT COUNT(*) FROM lesson WHERE kelas_id = ?) AS total_lesson,
      (SELECT COUNT(*) FROM quiz WHERE kelas_id = ?) AS total_quiz
  `;

  db.query(totalQuery, [kelas_id, kelas_id], (err, totalResult) => {
    if (err) return res.status(500).json({ error: err.message });

    const { total_lesson, total_quiz } = totalResult[0];

    const selesaiQuery = `
      SELECT 
        (SELECT COUNT(*) FROM lesson_progress_user lpu 
         JOIN lesson l ON l.id = lpu.lesson_id 
         WHERE lpu.user_id = ? AND l.kelas_id = ? AND lpu.status = 'sudah') AS selesai_lesson,
         
        (SELECT COUNT(*) FROM quiz_progress_user qpu 
         JOIN quiz q ON q.id = qpu.quiz_id 
         WHERE qpu.user_id = ? AND q.kelas_id = ? AND qpu.status = 'sudah') AS selesai_quiz
    `;

    db.query(selesaiQuery, [user_id, kelas_id, user_id, kelas_id], (err2, selesaiResult) => {
      if (err2) return res.status(500).json({ error: err2.message });

      const { selesai_lesson, selesai_quiz } = selesaiResult[0];

      const total = total_lesson + total_quiz;
      const selesai = selesai_lesson + selesai_quiz;

      const progress = total === 0 ? 0 : Math.round((selesai / total) * 100);

      res.json({
        progress: `${progress}%`,
        detail: {
          total_lesson,
          total_quiz,
          selesai_lesson,
          selesai_quiz,
        }
      });
    });
  });
};