const multer = require('multer');
const path = require('path');
const crypto = require('crypto');
const db = require('../config/db');

// Konfigurasi multer
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage });

// Upload produk baru
const uploadProduct = (req, res) => {
  const { nama_produk, detail_produk, harga, komisi, link_produk, kategori, ID_Perusahaan } = req.body;
  const gambar_produk = req.file?.filename;

  if (!gambar_produk || !nama_produk || !detail_produk || !harga || !kategori || !ID_Perusahaan) {
    return res.status(400).json({ error: 'nama_produk, harga, gambar_produk, detail_produk, dan ID_Perusahaan wajib diisi' });
  }

  const hargaAngka = parseFloat(harga);
  const finalKomisi = komisi ? parseFloat(komisi) : 0.05 * hargaAngka;

  const sql = `
    INSERT INTO produk (gambar_produk, nama_produk, detail_produk, harga, komisi, link_produk, kategori, ID_Perusahaan)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
  db.query(sql, [gambar_produk, nama_produk, detail_produk, hargaAngka, finalKomisi, link_produk, kategori, ID_Perusahaan], (err, result) => {
    if (err) {
      console.error("Database error:", err);
      return res.status(500).json({ error: 'Database error' });
    }

    res.status(201).json({
      message: 'Produk berhasil ditambahkan',
      data: {
        gambar_produk,
        nama_produk,
        detail_produk,
        harga: hargaAngka,
        komisi: finalKomisi,
        link_produk,
        kategori,
        ID_Perusahaan
      }
    });
  });
};

// Ambil semua produk beserta jumlah pengambil
const getAllProduk = (req, res) => {
  const sql = `
    SELECT p.*, 
      (SELECT COUNT(*) FROM user_produk up WHERE up.ID_Produk = p.id) AS jumlah_diambil
    FROM produk p
  `;

  db.query(sql, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Gagal mengambil data produk' });
    }

    res.json(result);
  });
};

// User mengambil produk (hanya sekali)
const ambilProdukOlehUser = (req, res) => {
  const id_produk = req.params.id_produk;
  const id_user = req.user.id;

  const checkSql = `
    SELECT * FROM user_produk WHERE ID_User = ? AND ID_Produk = ?
  `;

  db.query(checkSql, [id_user, id_produk], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Gagal mengecek data' });

    if (rows.length > 0) {
      return res.json({
        message: 'Produk sudah pernah diambil sebelumnya',
        custom_link: rows[0].custom_link
      });
    }

    const custom_code = crypto.randomBytes(6).toString('hex');

    const getLinkSql = `SELECT link_produk FROM produk WHERE ID_Produk = ?`;
    db.query(getLinkSql, [id_produk], (err2, linkRows) => {
      if (err2 || linkRows.length === 0) {
        return res.status(404).json({ error: 'Produk tidak ditemukan' });
      }

      const link_produk_asli = linkRows[0].link_produk;
      const affiliateLink = `${link_produk_asli}?ref=${custom_code}`;

      const insertSql = `
        INSERT INTO user_produk (ID_User, ID_Produk, custom_link)
        VALUES (?, ?, ?)
      `;
      db.query(insertSql, [id_user, id_produk, affiliateLink], (err3) => {
        if (err3) {
          console.error("Insert affiliate error:", err3); // Tambahkan log ke terminal
          return res.status(500).json({ error: 'Gagal menyimpan affiliate', detail: err3.message });
        }


        res.json({
          message: 'Berhasil mengambil produk affiliate',
          custom_link: affiliateLink
        });
      });
    });
  });
};

// Ambil daftar produk yang diambil user
const getProdukSaya = (req, res) => {
  const id_user = req.user.id;

  const sql = `
    SELECT 
      p.*, 
      up.custom_link,
      up.tanggal_ambil
    FROM user_produk up
    JOIN produk p ON up.ID_Produk = p.ID_Produk
    WHERE up.ID_User = ?
  `;

  db.query(sql, [id_user], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'Gagal mengambil produk saya' });
    }

    res.json(result);
  });
};

module.exports = {
  uploadProduct,
  upload,
  getAllProduk,
  ambilProdukOlehUser,
  getProdukSaya
};
