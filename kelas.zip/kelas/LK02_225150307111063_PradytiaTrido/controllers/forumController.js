// controllers/forumController.js
const db = require("../config/db");

exports.getAllForum = (req, res) => {
  const query = "SELECT * FROM forum ORDER BY created_at DESC";
  db.query(query, (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
};

exports.getForumById = (req, res) => {
  const { id } = req.params;
  const query = "SELECT * FROM forum WHERE id = ?";
  db.query(query, [id], (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    if (results.length === 0) return res.status(404).json({ message: "Forum not found" });
    res.json(results[0]);
  });
};

exports.createForum = (req, res) => {
  const { title, description} = req.body;
  const user_id = req.user?.id;

  if (!title || !description) {
    return res.status(400).json({ message: "Title and description are required" });
  }
  if(!user_id) {
    return res.status(401).json({ message: "Unauthorized. User ID missing from token." });
  }

  const query = "INSERT INTO forum (title, description, user_id) VALUES (?, ?, ?)";
  db.query(query, [title, description, user_id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(201).json({ message: "Forum created", forumId: result.insertId });
  });
};

exports.deleteForum = (req, res) => {
  const { id } = req.params;
  const query = "DELETE FROM forum WHERE id = ?";
  db.query(query, [id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: "Forum deleted" });
  });
};