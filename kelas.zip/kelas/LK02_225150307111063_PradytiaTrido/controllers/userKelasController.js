const db = require("../config/db");

exports.getKelasUser = (req, res) => {
  const { user_id, status } = req.query;

  if (!user_id || !status) {
    return res.status(400).json({ message: "user_id dan status wajib diisi!" });
  }

  // Ambil daftar kelas yang user ikuti dari tabel user_course
  const getUserCoursesQuery = `
    SELECT k.id, k.nama_kelas, k.deskripsi, k.created_at, k.is_premium
    FROM user_course uc
    JOIN kelas k ON uc.kelas_id = k.id
    WHERE uc.user_id = ?
  `;

  db.query(getUserCoursesQuery, [user_id], async (err, kelasResults) => {
    if (err) {
      console.error("Gagal mengambil kelas user:", err);
      return res.status(500).json({ message: "Terjadi kesalahan server." });
    }

    // Hitung progress untuk masing-masing kelas
    const kelasDenganProgress = await Promise.all(kelasResults.map(kelas => {
      return new Promise((resolve, reject) => {
        const kelasId = kelas.id;

        const totalQuery = `
          SELECT 
            (SELECT COUNT(*) FROM lesson WHERE kelas_id = ?) AS total_lesson,
            (SELECT COUNT(*) FROM quiz WHERE kelas_id = ?) AS total_quiz
        `;

        db.query(totalQuery, [kelasId, kelasId], (err, totalResult) => {
          if (err) return reject(err);

          const { total_lesson, total_quiz } = totalResult[0];
          const totalItem = total_lesson + total_quiz;

          if (totalItem === 0) {
            kelas.progress = 0;
            return resolve(kelas);
          }

          const userProgressQuery = `
            SELECT
              (SELECT COUNT(*) FROM lesson_progress_user lp
               JOIN lesson l ON lp.lesson_id = l.id
               WHERE lp.user_id = ? AND l.kelas_id = ? AND lp.status = 'sudah') AS lesson_done,
              (SELECT COUNT(*) FROM quiz_progress_user qp
               JOIN quiz q ON qp.quiz_id = q.id
               WHERE qp.user_id = ? AND q.kelas_id = ? AND qp.status = 'sudah') AS quiz_done
          `;

          db.query(userProgressQuery, [user_id, kelasId, user_id, kelasId], (err, userResult) => {
            if (err) return reject(err);

            const { lesson_done, quiz_done } = userResult[0];
            const progress = Math.round(((lesson_done + quiz_done) / totalItem) * 100);

            kelas.progress = progress;
            resolve(kelas);
          });
        });
      });
    }));

    // Filter berdasarkan status: ongoing atau completed
    let filteredKelas = [];
    if (status === "ongoing") {
      filteredKelas = kelasDenganProgress.filter(k => k.progress < 100);
    } else if (status === "completed") {
      filteredKelas = kelasDenganProgress.filter(k => k.progress === 100);
    } else {
      return res.status(400).json({ message: "Status hanya boleh 'ongoing' atau 'completed'!" });
    }

    res.status(200).json({
      message: `Daftar kelas dengan status '${status}' berhasil diambil!`,
      data: filteredKelas,
    });
  });
};