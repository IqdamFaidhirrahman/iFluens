const db = require("../config/db");

// POST - user mengambil kelas
exports.ambilKelas = (req, res) => {
    const { user_id, kelas_id } = req.body;

    if (!user_id || !kelas_id) {
        return res.status(400).json({ message: "user_id dan kelas_id wajib diisi." });
    }

    const query = "INSERT INTO user_course (user_id, kelas_id) VALUES (?, ?)";

    db.query(query, [user_id, kelas_id], (err, result) => {
        if (err) {
            // Tangani jika user sudah mengambil kelas
            if (err.code === "ER_DUP_ENTRY") {
                return res.status(409).json({ message: "Kelas sudah diambil sebelumnya." });
            }

            // Tangani jika user_id atau kelas_id tidak ditemukan (gagal referensi foreign key)
            if (err.code === "ER_NO_REFERENCED_ROW_2") {
                return res.status(400).json({ message: "User atau kelas tidak ditemukan." });
            }

            // Tangani error lainnya
            return res.status(500).json({ message: "Gagal mengambil kelas." });
        }

        res.status(201).json({ message: "Kelas berhasil diambil!" });
    });
};

// GET - tampilkan semua kelas yang diambil user
exports.getKelasSaya = (req, res) => {
    const { user_id } = req.query;

    if (!user_id) {
        return res.status(400).json({ message: "user_id wajib diberikan sebagai query." });
    }

    const query = `
        SELECT k.id, k.nama_kelas, k.deskripsi, uc.tanggal_diambil
        FROM user_course uc
        JOIN kelas k ON uc.kelas_id = k.id
        WHERE uc.user_id = ?
    `;

    db.query(query, [user_id], (err, results) => {
        if (err) {
            return res.status(500).json({ message: "Gagal mengambil daftar kelas." });
        }

        res.status(200).json({
            message: "Daftar kelas yang diambil berhasil diambil",
            data: results,
        });
    });
};