const db = require("../config/db");

// POST - Membuat pembayaran baru
exports.buatPembayaran = (req, res) => {
    const { user_id, kelas_id, metode_pembayaran } = req.body;

  // Cek apakah kelas adalah premium
  const queryCekKelas = "SELECT is_premium FROM kelas WHERE id = ?";
  db.query(queryCekKelas, [kelas_id], (err, kelasResult) => {
    if (err) {
      console.error("Gagal mengecek kelas:", err);
      return res.status(500).json({ message: "Terjadi kesalahan saat mengecek kelas", error: err });
    }

    if (kelasResult.length === 0) {
      return res.status(404).json({ message: "Kelas tidak ditemukan." });
    }

    const isPremium = kelasResult[0].is_premium;

    if (!isPremium) {
      return res.status(400).json({ message: "Kelas ini tidak memerlukan pembayaran (gratis)." });
    }

    // Lanjutkan simpan pembayaran
    const query = `
      INSERT INTO pembayaran (user_id, kelas_id, metode_pembayaran, status_pembayaran, tanggal_pembayaran)
      VALUES (?, ?, ?, 'menunggu_konfirmasi', NOW())
    `;

    db.query(query, [user_id, kelas_id, metode_pembayaran], (err, result) => {
      if (err) {
        console.error("Gagal membuat pembayaran:", err);
        return res.status(500).json({ message: "Gagal membuat pembayaran", error: err });
      }

      res.status(201).json({
        message: "Pembayaran berhasil dibuat, menunggu konfirmasi.",
        data: {
          id: result.insertId,
          user_id,
          kelas_id,
          metode_pembayaran,
          status_pembayaran: "menunggu_konfirmasi"
        }
      });
    });
  });
};

// PUT - Verifikasi pembayaran (simulasi admin lewat Postman)
exports.verifikasiPembayaran = (req, res) => {
    const { user_id, kelas_id } = req.body;

    if (!user_id || !kelas_id) {
        return res.status(400).json({ message: "user_id dan kelas_id wajib diisi." });
    }

    const query = `
        UPDATE pembayaran
        SET status_pembayaran = 'berhasil'
        WHERE user_id = ? AND kelas_id = ? AND status_pembayaran = 'menunggu_konfirmasi'
    `;

    db.query(query, [user_id, kelas_id], (err, result) => {
        if (err) {
            return res.status(500).json({ message: "Gagal memverifikasi pembayaran", error: err });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Tidak ditemukan pembayaran yang perlu diverifikasi." });
        }

        return res.status(200).json({ message: "Pembayaran berhasil diverifikasi!" });
    });
};

// GET - Lihat semua pembayaran user
exports.getPembayaranUser = (req, res) => {
    const { user_id } = req.query;

    if (!user_id) {
        return res.status(400).json({ message: "user_id wajib diberikan." });
    }

    const query = `
        SELECT p.*, k.nama_kelas
        FROM pembayaran p
        JOIN kelas k ON p.kelas_id = k.id
        WHERE p.user_id = ?
    `;

    db.query(query, [user_id], (err, results) => {
        if (err) {
            return res.status(500).json({ message: "Gagal mengambil data pembayaran", error: err });
        }

        return res.status(200).json({
            message: "Data pembayaran berhasil diambil",
            data: results,
        });
    });
};