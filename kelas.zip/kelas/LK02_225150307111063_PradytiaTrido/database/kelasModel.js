const db = require('../config/db');

const Kelas = {
  getAll: (callback) => {
    db.query('SELECT * FROM kelas', callback);
  },

  getById: (id, callback) => {
    db.query('SELECT * FROM kelas WHERE id = ?', [id], callback);
  },

  create: (data, callback) => {
    db.query('INSERT INTO kelas (nama_kelas, deskripsi) VALUES (?, ?)', [data.nama_kelas, data.deskripsi], callback);
  },

  update: (id, data, callback) => {
    db.query('UPDATE kelas SET nama_kelas = ?, deskripsi = ? WHERE id = ?', [data.nama_kelas, data.deskripsi, id], callback);
  },

  delete: (id, callback) => {
    db.query('DELETE FROM kelas WHERE id = ?', [id], callback);
  },
};

module.exports = Kelas;