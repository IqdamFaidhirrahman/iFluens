const express = require('express');
const router = express.Router();
const quizController = require('../controllers/quizController');

router.get('/:quiz_id/questions', quizController.getQuizWithQuestions);

module.exports = router;
