// routes/forumRoutes.js
const express = require("express");
const router = express.Router();
const forumController = require("../controllers/forumController");
const verifyToken = require("../middleware/authMiddleware");

// Public routes
router.get("/", forumController.getAllForum);
router.get("/:id", forumController.getForumById);
// Protected routes
router.post("/", forumController.createForum);
router.delete("/:id", forumController.deleteForum);


module.exports = router;