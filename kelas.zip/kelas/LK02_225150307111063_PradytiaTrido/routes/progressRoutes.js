const express = require('express');
const router = express.Router();
const progressController = require('../controllers/progressController');

router.get('/progress/:user_id/:kelas_id', progressController.getUserProgress);

module.exports = router;
