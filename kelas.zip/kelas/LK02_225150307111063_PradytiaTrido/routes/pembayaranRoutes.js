const express = require("express");
const router = express.Router();
const pembayaranController = require("../controllers/pembayaranController");

router.post("/", pembayaranController.buatPembayaran);                // User bayar
router.put("/verifikasi", pembayaranController.verifikasiPembayaran); // Admin verifikasi
router.get("/", pembayaranController.getPembayaranUser);              // Lihat status

module.exports = router;