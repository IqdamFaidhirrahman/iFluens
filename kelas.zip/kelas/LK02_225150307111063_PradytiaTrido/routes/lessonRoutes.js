const express = require('express');
const router = express.Router();
const lessonController = require('../controllers/lessonController');

// Endpoint untuk menandai lesson sudah ditonton dan menambahkan lesson
router.post('/lesson-progress', lessonController.markLessonAsWatched);
router.post("/tambah", lessonController.tambahLesson);

module.exports = router;