const express = require("express");
const router = express.Router();
const userCourseController = require("../controllers/userCourseController");

// POST: user ambil kelas
router.post("/ambil", userCourseController.ambilKelas);

// GET: lihat daftar kelas yang diambil user
router.get("/", userCourseController.getKelasSaya);

module.exports = router;