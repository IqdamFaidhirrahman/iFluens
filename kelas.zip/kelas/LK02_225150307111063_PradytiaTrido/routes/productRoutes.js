const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');
const verifyToken = require('../middleware/authMiddleware');

// Endpoint: Ambil semua produk (tidak perlu autentikasi)
router.get('/', productController.getAllProduk);

// Endpoint: Upload produk (dilindungi token JWT)
router.post(
  '/produk',
  verifyToken,
  productController.upload.single('gambar_produk'),
  productController.uploadProduct
);

// Endpoint: User ambil produk (dilindungi token JWT)
router.post('/ambil/:id_produk', verifyToken, productController.ambilProdukOlehUser);

module.exports = router;