// routes/perusahaanRoutes.js

const express = require('express');
const router = express.Router();
const { addPerusahaan } = require('../controllers/perusahaanController');

// Endpoint untuk menambahkan perusahaan baru
router.post('/', addPerusahaan);

module.exports = router;
