const express = require("express");
const router = express.Router();
const userKelasController = require("../controllers/userKelasController");

router.get("/", userKelasController.getKelasUser);

module.exports = router;