const express = require("express");
const router = express.Router();
const kelasController = require("../controllers/kelasController");
const validateKelas = require("../middleware/kelasValidator");

router.post("/tambah", validateKelas, kelasController.tambahKelas);
router.get("/", kelasController.getSemuaKelas);
router.get("/:id", kelasController.getKelasById);
router.get('/:id/materi', kelasController.getMateriByKelas);
router.put("/update/:id", validateKelas, kelasController.updateKelas);
router.delete("/hapus/:id", kelasController.hapusKelas);

module.exports = router;