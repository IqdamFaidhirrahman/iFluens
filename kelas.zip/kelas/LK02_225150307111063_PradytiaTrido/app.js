//memuat environment variable
require("./config/dotenv");

//import modul express
const express = require("express");

// import route authRoutes
const authRoutes = require("./routes/authRoutes");

// import route userRoutes
const userRoutes = require("./routes/userRoutes");

// import koneksi database
const db = require("./config/db");

// import modul cors
const cors = require("cors");

// import route userCourseRoutes
const userCourseRoutes = require("./routes/userCourseRoutes");

// import route productRoutes
const productRoutes = require('./routes/productRoutes');

// import route perusahaanRoutes
const perusahaanRoutes = require('./routes/perusahaanRoutes');

// import route kelasRoutes
const kelasRoutes = require('./routes/kelasRoutes');

// import route pembayaranRoutes
const pembayaranRoutes = require("./routes/pembayaranRoutes");

// import route lessonRoutes
const lessonRoutes = require('./routes/lessonRoutes');

// import route progressRoutes
const progressRoutes = require('./routes/progressRoutes');

// import route userKelasRoutes
const userKelasRoutes = require("./routes/userKelasRoutes");

// import route feedbackRoutes
const feedbackRoutes = require("./routes/feedbackRoutes");

// import route quizRoutes
const quizRoutes = require('./routes/quizRoutes');

//instance Express
const app = express();

// Middleware
app.use(cors()); // Mengaktifkan CORS
app.use(express.json()); // Parsing req.body dalam format JSON
app.use('/uploads', express.static('uploads')); // agar gambar bisa diakses
// Parsing data URL-encoded
app.use(express.urlencoded({ extended: true }));

// app.method(path, handler);
// Routes
app.use('/auth', authRoutes);
app.use('/user', userRoutes);
app.use('/api', productRoutes);
app.use('/api/perusahaan', perusahaanRoutes);
app.use('/api/kelas', kelasRoutes);
app.use('/api/my-courses', userCourseRoutes);
app.use('/api/pembayaran', pembayaranRoutes);
app.use('/api', lessonRoutes);
app.use('/api', progressRoutes);
app.use('/api/kelas-saya', userKelasRoutes);
app.use('/api/feedback', feedbackRoutes);
app.use('/api', quizRoutes);

//jalankan server
const PORT = process.env.SERVER_PORT;
app.get("/", (req, res) => {
    res.send("Backend berjalan dengan baik!");
});
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));