const jwt = require('jsonwebtoken');

const verifyToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];

  if (!authHeader) {
    return res.status(403).json({ message: "Token required" });
  }

  const tokenParts = authHeader.split(' ');
  if (tokenParts.length !== 2 || tokenParts[0] !== 'Bearer') {
    return res.status(403).json({ message: "Invalid token format. Use 'Bearer <token>'" });
  }

  const token = tokenParts[1];

  jwt.verify(token, process.env.JWT_SECRET || 'RAHASIA123', (err, decoded) => {
    if (err) {
      return res.status(401).json({ message: "Invalid or expired token" });
    }

    if (!decoded.id) {
      return res.status(400).json({ message: "Token does not contain user ID" });
    }

    req.user = decoded; // Menyimpan payload token ke req.user
    next();
  });
};

module.exports = verifyToken;
