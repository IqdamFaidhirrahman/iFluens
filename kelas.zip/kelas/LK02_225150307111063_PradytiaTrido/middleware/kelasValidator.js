module.exports = (req, res, next) => {
  const { nama_kelas, deskripsi } = req.body;

  if (!nama_kelas || !deskripsi) {
    return res.status(400).json({
      message: "Nama kelas dan deskripsi tidak boleh kosong.",
    });
  }

  next(); // lanjut ke controller kalau valid
};