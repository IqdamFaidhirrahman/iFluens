-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 17, 2025 at 08:19 AM
-- Server version: 8.4.3
-- PHP Version: 8.3.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ifluens_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat_komunitas`
--

CREATE TABLE `chat_komunitas` (
  `ID_Chat_Kom` int UNSIGNED NOT NULL,
  `ID_Komunitas` int UNSIGNED NOT NULL,
  `ID_Pengirim` int UNSIGNED NOT NULL,
  `isi_pesan` text COLLATE utf8mb4_general_ci,
  `waktu_kirim` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chat_pribadi`
--

CREATE TABLE `chat_pribadi` (
  `ID_Chat` int UNSIGNED NOT NULL,
  `ID_Pengirim` int UNSIGNED NOT NULL,
  `ID_Penerima` int UNSIGNED NOT NULL,
  `isi_pesan` text COLLATE utf8mb4_general_ci,
  `waktu_kirim` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status_baca` enum('belum dibaca','dibaca') COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback_kelas`
--

CREATE TABLE `feedback_kelas` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `kelas_id` int NOT NULL,
  `rating` int NOT NULL,
  `komentar` text,
  `tanggal_feedback` datetime DEFAULT CURRENT_TIMESTAMP
) ;

--
-- Dumping data for table `feedback_kelas`
--

INSERT INTO `feedback_kelas` (`id`, `user_id`, `kelas_id`, `rating`, `komentar`, `tanggal_feedback`) VALUES
(1, 1, 3, 5, 'Mantap banget kelasnya!', '2025-06-16 00:20:56');

-- --------------------------------------------------------

--
-- Table structure for table `forum_kategori`
--

CREATE TABLE `forum_kategori` (
  `id` int NOT NULL,
  `nama_kategori` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forum_komentar`
--

CREATE TABLE `forum_komentar` (
  `id` int NOT NULL,
  `id_pertanyaan` int NOT NULL,
  `ID_User` int UNSIGNED NOT NULL,
  `isi_komentar` text,
  `tanggal_dibuat` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forum_pertanyaan`
--

CREATE TABLE `forum_pertanyaan` (
  `id` int NOT NULL,
  `ID_User` int UNSIGNED NOT NULL,
  `kategori` varchar(50) DEFAULT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `isi` text,
  `anonim` tinyint(1) DEFAULT '0',
  `tanggal_dibuat` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `id` int NOT NULL,
  `nama_kelas` varchar(255) NOT NULL,
  `deskripsi` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_premium` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id`, `nama_kelas`, `deskripsi`, `created_at`, `is_premium`) VALUES
(3, 'PAMLan', 'Belajar android studio dengan kotlin', '2025-06-14 09:47:00', 0),
(4, 'Kelas Backend', 'Belajar membuat REST API', '2025-06-14 17:56:24', 1),
(5, 'Technopreneur', 'Belajar ilmu yang menggabungkan bisnis dan teknologi', '2025-06-14 17:59:14', 0);

-- --------------------------------------------------------

--
-- Table structure for table `komunitas`
--

CREATE TABLE `komunitas` (
  `ID_Komunitas` int UNSIGNED NOT NULL,
  `nama_komunitas` varchar(100) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lesson`
--

CREATE TABLE `lesson` (
  `id` int NOT NULL,
  `kelas_id` int NOT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `deskripsi` text,
  `urutan` int DEFAULT NULL,
  `video_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `thumbnail_url` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lesson`
--

INSERT INTO `lesson` (`id`, `kelas_id`, `judul`, `deskripsi`, `urutan`, `video_url`, `created_at`, `thumbnail_url`) VALUES
(1, 1, 'Materi 1: Pengenalan Flutter', NULL, NULL, 'https://youtu.be/srv5g8Xj7hY?si=OyoGcr_MrfFlJ5WB', '2025-06-17 03:22:00', 'https://www.bing.com/images/search?view=detailV2&ccid=jOYhInox&id=C9642CED7A93114D705E5352DF0D84AC039CE1C5&thid=OIP.jOYhInoxiSi1GFKwmSukIAHaHk&mediaurl=https%3a%2f%2fwww.techspot.com%2fimages2%2fdownloads%2ftopdownload%2f2022%2f02%2f2022-02-25-ts3_thumbs-8b5.png&exph=580&expw=567&q=android+studio+download&simid=607996735496606553&FORM=IRPRST&ck=F49CE4A52FC63259E2B597E3047A64CF&selectedIndex=32&itb=1'),
(3, 3, 'Materi 1: Pengenalan Android Studio', 'Android Studio merupakan salah satu platform mobile developer', NULL, 'https://youtu.be/srv5g8Xj7hY?si=OyoGcr_MrfFlJ5WB', '2025-06-17 03:47:11', 'https://www.bing.com/images/search?view=detailV2&ccid=jOYhInox&id=C9642CED7A93114D705E5352DF0D84AC039CE1C5&thid=OIP.jOYhInoxiSi1GFKwmSukIAHaHk&mediaurl=https%3a%2f%2fwww.techspot.com%2fimages2%2fdownloads%2ftopdownload%2f2022%2f02%2f2022-02-25-ts3_thumbs-8b5.png&exph=580&expw=567&q=android+studio+download&simid=607996735496606553&FORM=IRPRST&ck=F49CE4A52FC63259E2B597E3047A64CF&selectedIndex=32&itb=1');

-- --------------------------------------------------------

--
-- Table structure for table `lesson_progress_user`
--

CREATE TABLE `lesson_progress_user` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `lesson_id` int NOT NULL,
  `status` enum('belum','sudah') DEFAULT 'belum',
  `waktu_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `lesson_progress_user`
--

INSERT INTO `lesson_progress_user` (`id`, `user_id`, `lesson_id`, `status`, `waktu_update`) VALUES
(1, 1, 3, 'sudah', '2025-06-15 13:36:40');

-- --------------------------------------------------------

--
-- Table structure for table `notifikasi`
--

CREATE TABLE `notifikasi` (
  `ID_Notifikasi` int UNSIGNED NOT NULL,
  `ID_User` int UNSIGNED NOT NULL,
  `judul` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'judul notifikasi',
  `isi` text COLLATE utf8mb4_general_ci COMMENT 'isi lengkap notifikasi',
  `waktu_dikirim` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'waktu kirim',
  `status_baca` enum('belum dibaca','dibaca') COLLATE utf8mb4_general_ci NOT NULL COMMENT 'status apakah user sudah membaca'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `kelas_id` int NOT NULL,
  `metode_pembayaran` varchar(50) DEFAULT NULL,
  `tanggal_pembayaran` datetime DEFAULT CURRENT_TIMESTAMP,
  `status_pembayaran` enum('pending','menunggu_konfirmasi','berhasil') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id`, `user_id`, `kelas_id`, `metode_pembayaran`, `tanggal_pembayaran`, `status_pembayaran`) VALUES
(1, 1, 3, 'QRIS', '2025-06-15 00:01:51', 'berhasil'),
(2, 1, 4, 'QRIS', '2025-06-15 01:01:04', 'berhasil');

-- --------------------------------------------------------

--
-- Table structure for table `perusahaan`
--

CREATE TABLE `perusahaan` (
  `ID_Perusahaan` int UNSIGNED NOT NULL,
  `nama_perusahaan` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `alamat` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `perusahaan`
--

INSERT INTO `perusahaan` (`ID_Perusahaan`, `nama_perusahaan`, `alamat`) VALUES
(1, 'PT Sepatu Naga', 'Jalan Brawijaya No.11'),
(2, 'PT Sport Badminton', 'Jalan Filkom No.32');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `ID_Produk` int UNSIGNED NOT NULL,
  `ID_Perusahaan` int UNSIGNED DEFAULT NULL,
  `nama_produk` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `detail_produk` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `harga` int NOT NULL,
  `link_produk` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `kategori` enum('semua','fashion','lifestyle','home decor','olahraga') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `komisi` float DEFAULT NULL,
  `gambar_produk` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`ID_Produk`, `ID_Perusahaan`, `nama_produk`, `detail_produk`, `harga`, `link_produk`, `kategori`, `komisi`, `gambar_produk`) VALUES
(1, NULL, 'Sepatu ABC', NULL, 150000, 'https://shopee.co.id/produk/abc123', 'fashion', 7500, '1748942302904.jpeg'),
(2, NULL, 'Sepatu ABC', NULL, 150000, 'https://shopee.co.id/produk/abc123', 'fashion', 7500, '1749025888307.jpeg'),
(3, 2, 'Raket Yonex', 'Raket Yonex berwarna biru', 150000, 'https://shopee.co.id/produk/yonex', 'fashion', 7500, '1749032652792.jpg'),
(5, 2, 'Shuttlecock Gajah Mada', 'shuttlecock gajah mada satu slop berwarna merah untuk bermain badminton', 190000, 'https://shopee.co.id/produk/shuttlecock', 'olahraga', 9500, '1749060819889.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `id` int NOT NULL,
  `kelas_id` int NOT NULL,
  `judul` varchar(255) NOT NULL,
  `deskripsi` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`id`, `kelas_id`, `judul`, `deskripsi`, `created_at`) VALUES
(1, 3, 'Quiz Awal', 'Quiz pengantar kelas', '2025-06-15 16:28:35');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_progress_user`
--

CREATE TABLE `quiz_progress_user` (
  `id` int NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `quiz_id` int NOT NULL,
  `status` enum('belum','sudah') DEFAULT 'belum',
  `tanggal_diselesaikan` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `quiz_progress_user`
--

INSERT INTO `quiz_progress_user` (`id`, `user_id`, `quiz_id`, `status`, `tanggal_diselesaikan`) VALUES
(1, 1, 1, 'sudah', '2025-06-15 16:32:08'),
(2, 1, 1, 'sudah', '2025-06-17 07:58:37');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_question`
--

CREATE TABLE `quiz_question` (
  `id` int NOT NULL,
  `quiz_id` int NOT NULL,
  `pertanyaan` text NOT NULL,
  `pilihan_a` varchar(255) DEFAULT NULL,
  `pilihan_b` varchar(255) DEFAULT NULL,
  `pilihan_c` varchar(255) DEFAULT NULL,
  `pilihan_d` varchar(255) DEFAULT NULL,
  `jawaban_benar` enum('A','B','C','D') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `quiz_question`
--

INSERT INTO `quiz_question` (`id`, `quiz_id`, `pertanyaan`, `pilihan_a`, `pilihan_b`, `pilihan_c`, `pilihan_d`, `jawaban_benar`) VALUES
(1, 1, 'Apa nama IDE resmi untuk Android development?', 'Visual Studio', 'Android Studio', 'Eclipse', 'NetBeans', 'B'),
(2, 1, 'Bahasa utama yang digunakan untuk membuat aplikasi Android?', 'Kotlin', 'Swift', 'Ruby', 'Go', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `ID_Report` int NOT NULL,
  `ID_User` int UNSIGNED NOT NULL,
  `minggu_keberapa` enum('1','2','3','4') COLLATE utf8mb4_general_ci NOT NULL,
  `total_penjualan` int DEFAULT NULL,
  `total_klik` int DEFAULT NULL,
  `bukti_upload` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID_User` int UNSIGNED NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `no_hp` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `nama` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `gender` enum('Laki-laki','Perempuan') COLLATE utf8mb4_general_ci DEFAULT NULL,
  `foto_profil` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `provider` enum('local','google','facebook') COLLATE utf8mb4_general_ci NOT NULL,
  `provide_id` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `reset_token` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `reset_expires` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID_User`, `username`, `email`, `password`, `no_hp`, `nama`, `gender`, `foto_profil`, `tgl_lahir`, `provider`, `provide_id`, `reset_token`, `reset_expires`) VALUES
(1, 'tesuser', 'tesuser@example.com', '$2b$10$NgQj9Se9C.GQTSh5i5938eHwdTdCQDgI3NN48Kxm4AGVI6WNYUcUG', '081234567890', 'Tes User', NULL, NULL, NULL, 'local', NULL, 'fd2a03bb-e812-427c-9fb3-ed79cc059847', '2025-06-09 18:23:43'),
(3, 'adit', 'pradytia17@gmail.com', '$2b$10$EvTpLW7jSY5jMZsPUjx8YOFYqBGJ3gZvR3OFInJ644oEM1X/TD8sG', '081818181818', 'adit tarigan', NULL, NULL, NULL, 'local', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_course`
--

CREATE TABLE `user_course` (
  `id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `kelas_id` int NOT NULL,
  `tanggal_diambil` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user_course`
--

INSERT INTO `user_course` (`id`, `user_id`, `kelas_id`, `tanggal_diambil`) VALUES
(2, 1, 3, '2025-06-14 16:53:42'),
(5, 1, 4, '2025-06-15 01:00:24'),
(6, 1, 5, '2025-06-15 01:01:50');

-- --------------------------------------------------------

--
-- Table structure for table `user_komunitas`
--

CREATE TABLE `user_komunitas` (
  `ID_User` int UNSIGNED NOT NULL,
  `ID_Komunitas` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_produk`
--

CREATE TABLE `user_produk` (
  `ID_User` int UNSIGNED NOT NULL,
  `ID_Produk` int UNSIGNED NOT NULL,
  `custom_link` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tanggal_pilih` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_produk`
--

INSERT INTO `user_produk` (`ID_User`, `ID_Produk`, `custom_link`, `tanggal_pilih`) VALUES
(1, 5, 'https://shopee.co.id/produk/shuttlecock?ref=74b5108810ec', '2025-06-05 02:00:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat_komunitas`
--
ALTER TABLE `chat_komunitas`
  ADD PRIMARY KEY (`ID_Chat_Kom`),
  ADD KEY `fk_chatkomunitas_komunitas` (`ID_Komunitas`),
  ADD KEY `fk_chatkomunitas_user` (`ID_Pengirim`);

--
-- Indexes for table `chat_pribadi`
--
ALTER TABLE `chat_pribadi`
  ADD PRIMARY KEY (`ID_Chat`),
  ADD KEY `fk_chatpenerima_user` (`ID_Penerima`),
  ADD KEY `fk_chatpengirim_user` (`ID_Pengirim`);

--
-- Indexes for table `feedback_kelas`
--
ALTER TABLE `feedback_kelas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`,`kelas_id`);

--
-- Indexes for table `forum_kategori`
--
ALTER TABLE `forum_kategori`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama_kategori` (`nama_kategori`);

--
-- Indexes for table `forum_komentar`
--
ALTER TABLE `forum_komentar`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_pertanyaan` (`id_pertanyaan`),
  ADD KEY `ID_User` (`ID_User`);

--
-- Indexes for table `forum_pertanyaan`
--
ALTER TABLE `forum_pertanyaan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ID_User` (`ID_User`);

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `komunitas`
--
ALTER TABLE `komunitas`
  ADD PRIMARY KEY (`ID_Komunitas`);

--
-- Indexes for table `lesson`
--
ALTER TABLE `lesson`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lesson_progress_user`
--
ALTER TABLE `lesson_progress_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifikasi`
--
ALTER TABLE `notifikasi`
  ADD PRIMARY KEY (`ID_Notifikasi`),
  ADD KEY `fk_notifikasi_user` (`ID_User`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `kelas_id` (`kelas_id`);

--
-- Indexes for table `perusahaan`
--
ALTER TABLE `perusahaan`
  ADD PRIMARY KEY (`ID_Perusahaan`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`ID_Produk`),
  ADD KEY `idx_id_perusahaan` (`ID_Perusahaan`);

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kelas_id` (`kelas_id`);

--
-- Indexes for table `quiz_progress_user`
--
ALTER TABLE `quiz_progress_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `quiz_id` (`quiz_id`);

--
-- Indexes for table `quiz_question`
--
ALTER TABLE `quiz_question`
  ADD PRIMARY KEY (`id`),
  ADD KEY `quiz_id` (`quiz_id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`ID_Report`),
  ADD KEY `idx_id_user` (`ID_User`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID_User`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD UNIQUE KEY `uq_username` (`username`);

--
-- Indexes for table `user_course`
--
ALTER TABLE `user_course`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unik_user_kelas` (`user_id`,`kelas_id`),
  ADD KEY `kelas_id` (`kelas_id`);

--
-- Indexes for table `user_komunitas`
--
ALTER TABLE `user_komunitas`
  ADD PRIMARY KEY (`ID_User`,`ID_Komunitas`),
  ADD KEY `fk_userkomunitas_komunitas` (`ID_Komunitas`),
  ADD KEY `fk_userkomunitas_user` (`ID_User`);

--
-- Indexes for table `user_produk`
--
ALTER TABLE `user_produk`
  ADD PRIMARY KEY (`ID_User`,`ID_Produk`),
  ADD KEY `fk_userproduk_produk` (`ID_Produk`),
  ADD KEY `fk_userproduk_user` (`ID_User`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat_komunitas`
--
ALTER TABLE `chat_komunitas`
  MODIFY `ID_Chat_Kom` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chat_pribadi`
--
ALTER TABLE `chat_pribadi`
  MODIFY `ID_Chat` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback_kelas`
--
ALTER TABLE `feedback_kelas`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `forum_kategori`
--
ALTER TABLE `forum_kategori`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `forum_komentar`
--
ALTER TABLE `forum_komentar`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `forum_pertanyaan`
--
ALTER TABLE `forum_pertanyaan`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `komunitas`
--
ALTER TABLE `komunitas`
  MODIFY `ID_Komunitas` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lesson`
--
ALTER TABLE `lesson`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `lesson_progress_user`
--
ALTER TABLE `lesson_progress_user`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `notifikasi`
--
ALTER TABLE `notifikasi`
  MODIFY `ID_Notifikasi` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `perusahaan`
--
ALTER TABLE `perusahaan`
  MODIFY `ID_Perusahaan` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `ID_Produk` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `quiz`
--
ALTER TABLE `quiz`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `quiz_progress_user`
--
ALTER TABLE `quiz_progress_user`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `quiz_question`
--
ALTER TABLE `quiz_question`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `ID_Report` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID_User` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_course`
--
ALTER TABLE `user_course`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chat_komunitas`
--
ALTER TABLE `chat_komunitas`
  ADD CONSTRAINT `fk_chatkomunitas_komunitas` FOREIGN KEY (`ID_Komunitas`) REFERENCES `komunitas` (`ID_Komunitas`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_chatkomunitas_user` FOREIGN KEY (`ID_Pengirim`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `chat_pribadi`
--
ALTER TABLE `chat_pribadi`
  ADD CONSTRAINT `fk_chatpenerima_user` FOREIGN KEY (`ID_Penerima`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_chatpengirim_user` FOREIGN KEY (`ID_Pengirim`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `forum_komentar`
--
ALTER TABLE `forum_komentar`
  ADD CONSTRAINT `forum_komentar_ibfk_1` FOREIGN KEY (`id_pertanyaan`) REFERENCES `forum_pertanyaan` (`id`),
  ADD CONSTRAINT `forum_komentar_ibfk_2` FOREIGN KEY (`ID_User`) REFERENCES `user` (`ID_User`);

--
-- Constraints for table `forum_pertanyaan`
--
ALTER TABLE `forum_pertanyaan`
  ADD CONSTRAINT `forum_pertanyaan_ibfk_1` FOREIGN KEY (`ID_User`) REFERENCES `user` (`ID_User`);

--
-- Constraints for table `notifikasi`
--
ALTER TABLE `notifikasi`
  ADD CONSTRAINT `fk_notifikasi_user` FOREIGN KEY (`ID_User`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `pembayaran_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE,
  ADD CONSTRAINT `pembayaran_ibfk_2` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `produk`
--
ALTER TABLE `produk`
  ADD CONSTRAINT `fk_produk_perusahaan` FOREIGN KEY (`ID_Perusahaan`) REFERENCES `perusahaan` (`ID_Perusahaan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `quiz`
--
ALTER TABLE `quiz`
  ADD CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `quiz_progress_user`
--
ALTER TABLE `quiz_progress_user`
  ADD CONSTRAINT `quiz_progress_user_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE,
  ADD CONSTRAINT `quiz_progress_user_ibfk_2` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `quiz_question`
--
ALTER TABLE `quiz_question`
  ADD CONSTRAINT `quiz_question_ibfk_1` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `report`
--
ALTER TABLE `report`
  ADD CONSTRAINT `fk_report_user` FOREIGN KEY (`ID_User`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_course`
--
ALTER TABLE `user_course`
  ADD CONSTRAINT `user_course_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_course_ibfk_2` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_komunitas`
--
ALTER TABLE `user_komunitas`
  ADD CONSTRAINT `fk_userkomunitas_komunitas` FOREIGN KEY (`ID_Komunitas`) REFERENCES `komunitas` (`ID_Komunitas`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_userkomunitas_user` FOREIGN KEY (`ID_User`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_produk`
--
ALTER TABLE `user_produk`
  ADD CONSTRAINT `fk_userproduk_produk` FOREIGN KEY (`ID_Produk`) REFERENCES `produk` (`ID_Produk`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_userproduk_user` FOREIGN KEY (`ID_User`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
