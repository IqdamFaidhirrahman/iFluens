const express = require("express");
const router = express.Router();
const verifyToken = require("../middleware/authMiddleware");
const { registerUser, loginUser } = require("../controllers/authController");
const db = require("../config/db");

// Endpoint register & login
router.post("/register", registerUser);
router.post("/login", loginUser);

// Endpoint untuk mendapatkan profile user
router.get("/profile", verifyToken, (req, res) => {
    const email = req.user.email;
    const sql = "SELECT id, email, nama FROM user WHERE email = ?";

    db.query(sql, [email], (err, result) => {
        if (err) {
            return res.status(500).json({ message: "Database error", error: err });
        }
        if (result.length === 0) {
            return res.status(404).json({ message: "User not found" });
        }
        res.json(result[0]);
    });
});

module.exports = router;
