-- Hapus tabel users jika sudah ada
DROP TABLE IF EXISTS users;

-- Buat tabel users
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

-- -- Tambahkan data dummy
-- INSERT INTO users (name, email, password) VALUES
-- ('Pradytia', 'pradytiatrido@student.ub.ac.id', '12345678'),
-- ('ababa', 'ababa@email.com', 'password123'),
-- ('adada', 'adada@email.com', 'password456');