-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: ifluens_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chat_komunitas`
--

DROP TABLE IF EXISTS `chat_komunitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_komunitas` (
  `ID_Chat_Kom` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ID_Komunitas` int(11) unsigned NOT NULL,
  `ID_Pengirim` int(11) unsigned NOT NULL,
  `isi_pesan` text DEFAULT NULL,
  `waktu_kirim` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID_Chat_Kom`),
  KEY `fk_chatkomunitas_komunitas` (`ID_Komunitas`),
  KEY `fk_chatkomunitas_user` (`ID_Pengirim`),
  CONSTRAINT `fk_chatkomunitas_komunitas` FOREIGN KEY (`ID_Komunitas`) REFERENCES `komunitas` (`ID_Komunitas`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_chatkomunitas_user` FOREIGN KEY (`ID_Pengirim`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_komunitas`
--

LOCK TABLES `chat_komunitas` WRITE;
/*!40000 ALTER TABLE `chat_komunitas` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_komunitas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_pribadi`
--

DROP TABLE IF EXISTS `chat_pribadi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_pribadi` (
  `ID_Chat` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ID_Pengirim` int(11) unsigned NOT NULL,
  `ID_Penerima` int(11) unsigned NOT NULL,
  `isi_pesan` text DEFAULT NULL,
  `waktu_kirim` datetime NOT NULL DEFAULT current_timestamp(),
  `status_baca` enum('belum dibaca','dibaca') NOT NULL,
  PRIMARY KEY (`ID_Chat`),
  KEY `fk_chatpenerima_user` (`ID_Penerima`),
  KEY `fk_chatpengirim_user` (`ID_Pengirim`),
  CONSTRAINT `fk_chatpenerima_user` FOREIGN KEY (`ID_Penerima`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_chatpengirim_user` FOREIGN KEY (`ID_Pengirim`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_pribadi`
--

LOCK TABLES `chat_pribadi` WRITE;
/*!40000 ALTER TABLE `chat_pribadi` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_pribadi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `komunitas`
--

DROP TABLE IF EXISTS `komunitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `komunitas` (
  `ID_Komunitas` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nama_komunitas` varchar(100) NOT NULL,
  PRIMARY KEY (`ID_Komunitas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `komunitas`
--

LOCK TABLES `komunitas` WRITE;
/*!40000 ALTER TABLE `komunitas` DISABLE KEYS */;
/*!40000 ALTER TABLE `komunitas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifikasi`
--

DROP TABLE IF EXISTS `notifikasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifikasi` (
  `ID_Notifikasi` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ID_User` int(11) unsigned NOT NULL,
  `judul` varchar(100) NOT NULL COMMENT 'judul notifikasi',
  `isi` text DEFAULT NULL COMMENT 'isi lengkap notifikasi',
  `waktu_dikirim` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'waktu kirim',
  `status_baca` enum('belum dibaca','dibaca') NOT NULL COMMENT 'status apakah user sudah membaca',
  PRIMARY KEY (`ID_Notifikasi`),
  KEY `fk_notifikasi_user` (`ID_User`),
  CONSTRAINT `fk_notifikasi_user` FOREIGN KEY (`ID_User`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifikasi`
--

LOCK TABLES `notifikasi` WRITE;
/*!40000 ALTER TABLE `notifikasi` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifikasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `perusahaan`
--

DROP TABLE IF EXISTS `perusahaan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `perusahaan` (
  `ID_Perusahaan` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nama_perusahaan` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  PRIMARY KEY (`ID_Perusahaan`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `perusahaan`
--

LOCK TABLES `perusahaan` WRITE;
/*!40000 ALTER TABLE `perusahaan` DISABLE KEYS */;
/*!40000 ALTER TABLE `perusahaan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produk`
--

DROP TABLE IF EXISTS `produk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produk` (
  `ID_Produk` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ID_Perusahaan` int(11) unsigned DEFAULT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `detail_produk` varchar(255) DEFAULT NULL,
  `harga` int(11) NOT NULL,
  `link_produk` varchar(255) NOT NULL,
  `kategori` enum('fashion','lifestyle','home decor') NOT NULL,
  `komisi` int(11) NOT NULL,
  PRIMARY KEY (`ID_Produk`),
  KEY `idx_id_perusahaan` (`ID_Perusahaan`),
  CONSTRAINT `fk_produk_perusahaan` FOREIGN KEY (`ID_Perusahaan`) REFERENCES `perusahaan` (`ID_Perusahaan`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produk`
--

LOCK TABLES `produk` WRITE;
/*!40000 ALTER TABLE `produk` DISABLE KEYS */;
/*!40000 ALTER TABLE `produk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report` (
  `ID_Report` int(11) NOT NULL AUTO_INCREMENT,
  `ID_User` int(11) unsigned NOT NULL,
  `minggu_keberapa` enum('1','2','3','4') NOT NULL,
  `total_penjualan` int(11) DEFAULT NULL,
  `total_klik` int(11) DEFAULT NULL,
  `bukti_upload` varchar(255) NOT NULL,
  PRIMARY KEY (`ID_Report`),
  KEY `idx_id_user` (`ID_User`),
  CONSTRAINT `fk_report_user` FOREIGN KEY (`ID_User`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `ID_User` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `gender` enum('Laki-laki','Perempuan') DEFAULT NULL,
  `foto_profil` varchar(255) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `provider` enum('local','google','facebook') NOT NULL,
  `provide_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID_User`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `uq_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_komunitas`
--

DROP TABLE IF EXISTS `user_komunitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_komunitas` (
  `ID_User` int(11) unsigned NOT NULL,
  `ID_Komunitas` int(11) unsigned NOT NULL,
  PRIMARY KEY (`ID_User`,`ID_Komunitas`),
  KEY `fk_userkomunitas_komunitas` (`ID_Komunitas`),
  KEY `fk_userkomunitas_user` (`ID_User`),
  CONSTRAINT `fk_userkomunitas_komunitas` FOREIGN KEY (`ID_Komunitas`) REFERENCES `komunitas` (`ID_Komunitas`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_userkomunitas_user` FOREIGN KEY (`ID_User`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_komunitas`
--

LOCK TABLES `user_komunitas` WRITE;
/*!40000 ALTER TABLE `user_komunitas` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_komunitas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_produk`
--

DROP TABLE IF EXISTS `user_produk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_produk` (
  `ID_User` int(11) unsigned NOT NULL,
  `ID_Produk` int(11) unsigned NOT NULL,
  `custom_link` varchar(255) DEFAULT NULL,
  `tanggal_pilih` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`ID_User`,`ID_Produk`),
  KEY `fk_userproduk_produk` (`ID_Produk`),
  KEY `fk_userproduk_user` (`ID_User`),
  CONSTRAINT `fk_userproduk_produk` FOREIGN KEY (`ID_Produk`) REFERENCES `produk` (`ID_Produk`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_userproduk_user` FOREIGN KEY (`ID_User`) REFERENCES `user` (`ID_User`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_produk`
--

LOCK TABLES `user_produk` WRITE;
/*!40000 ALTER TABLE `user_produk` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_produk` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-20 17:57:14
