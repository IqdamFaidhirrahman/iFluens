//memuat environment variable
require("./config/dotenv");

//import modul express
const express = require("express");

// import route authRoutes
const authRoutes = require("./routes/authRoutes");

// import route userRoutes
const userRoutes = require("./routes/userRoutes");

// import koneksi database
const db = require("./config/db");

// import modul cors
const cors = require("cors");

//instance Express
const app = express();

// Middleware
app.use(cors()); // Mengaktifkan CORS
app.use(express.json()); // Parsing req.body dalam format JSON
// Parsing data URL-encoded
app.use(express.urlencoded({ extended: true }));

// app.method(path, handler);
// Routes
app.use("/auth", authRoutes);
app.use("/user", userRoutes);

//jalankan server
const PORT = process.env.SERVER_PORT;
app.get("/", (req, res) => {
    res.send("Backend berjalan dengan baik!");
});
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));