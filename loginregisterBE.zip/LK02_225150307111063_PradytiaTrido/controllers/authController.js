const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/db');

// REGISTER
const registerUser = async (req, res) => {
  const { username, nama, email, password, konfirmasiPassword, no_hp } = req.body;

  if (password !== konfirmasiPassword) {
    return res.status(400).json({ message: "Konfirmasi password tidak cocok" });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const sql = "INSERT INTO user (username, nama, email, password, no_hp) VALUES (?, ?, ?, ?, ?)";
    const values = [username, nama, email, hashedPassword, no_hp];

    db.query(sql, values, (err, result) => {
      if (err) {
        console.error("Error saat register:", err);
        return res.status(500).json({ message: "Gagal register", error: err });
      }
      return res.status(201).json({ message: "Register berhasil" });
    });
  } catch (error) {
    return res.status(500).json({ message: "Terjadi kesalahan saat register" });
  }
};

// LOGIN
const loginUser = async (req, res) => {
  const { email, password } = req.body;

  db.query("SELECT * FROM User WHERE email = ?", [email], async (err, results) => {
    if (err) return res.status(500).json({ message: "Kesalahan server" });

    if (results.length === 0) {
      return res.status(404).json({ message: "Email tidak ditemukan" });
    }

    const user = results[0];
    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.status(401).json({ message: "Password salah" });
    }

    // Tambahan opsional: JWT
    const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET || "RAHASIA123", {
      expiresIn: "1h",
    });

    return res.status(200).json({ message: "Login berhasil", user, token });
  });
};

module.exports = { registerUser, loginUser };
